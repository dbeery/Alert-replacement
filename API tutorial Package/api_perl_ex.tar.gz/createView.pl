#!/usr/bin/perl

use RPC::XML;
use RPC::XML::Client;

my $host=$ARGV[0];
my $port=$ARGV[1];
my $client = new RPC::XML::Client 'http://' . $host . ':' . $port . '/xmlrpc';

#CREATE a view
my $req = RPC::XML::request->new('ME_API.API_Sampler.createView', 'View1', 'ME_API');
my $res = $client->send_request($req);

if ($res->value ne "OK") {
    print "Response type - " .$res->type ."\n";
    print "Response string - " .$res->as_string ."\n";
}
else {
    print "Response value - " .$res->value ."\n";
}

