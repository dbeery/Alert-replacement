#!/usr/bin/perl

use RPC::XML;
use RPC::XML::Client;

my $host=$ARGV[0];
my $port=$ARGV[1];
my $client = new RPC::XML::Client 'http://' . $host . ':' . $port . '/xmlrpc';

# time in secs between updates
$sleep_secs=0.10;

$val=10;
# initial headline value
$hl_val=0;

#Update Table Cells
while (1) {
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColA',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColB',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColC',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColA',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColB',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColC',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColA',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColB',$val);
    $res = $client->send_request($req);
    select(undef,undef,undef,$sleep_secs);
    $val++;
    $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColC',$val);
    $res = $client->send_request($req);

    #Update the headline
    $hl_val++;
    my $req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateHeadline', 'Headline', $hl_val);
    my $res = $client->send_request($req);

    select(undef,undef,undef,$sleep_secs);
}    
