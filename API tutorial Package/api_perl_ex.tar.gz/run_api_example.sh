#!/bin/sh

if [ $# -ne 2 ]
then
    echo "usage: $0 <host> <port>"
    exit
fi

host=$1
port=$2

echo "Creating view"
./createView.pl $host $port
echo "Sleeping 10 secs..."
sleep 10
echo "Creating headline"
./createheadline.pl $host $port
echo "Sleeping 10 secs..."
sleep 10
echo "Updating headline"
./updateheadline.pl $host $port
echo "Sleeping 10 secs..."
sleep 10
echo "Creating table"
./createTable.pl $host $port
echo "Sleeping 10 secs..."
sleep 10

echo "Return to continue with updates?"
read cont
./continual_updates.pl $host $port
