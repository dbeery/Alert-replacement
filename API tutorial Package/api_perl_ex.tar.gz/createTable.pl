#!/usr/bin/perl

use RPC::XML;
use RPC::XML::Client;

my $host=$ARGV[0];
my $port=$ARGV[1];
my $client = new RPC::XML::Client 'http://' . $host . ':' . $port . '/xmlrpc';


#Create Table
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableColumn', 'name');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableColumn', 'ColA');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableColumn', 'ColB');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableColumn', 'ColC');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableRow', 'Row1');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableRow', 'Row2');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.addTableRow', 'Row3');
$res = $client->send_request($req);



#Update Table Cells
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColA','1');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColB','2');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row1.ColC','3');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColA','4');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColB','5');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row2.ColC','6');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColA','7');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColB','8');
$res = $client->send_request($req);
$req = RPC::XML::request->new('ME_API.API_Sampler.ME_API-View1.updateTableCell', 'Row3.ColC','9');
$res = $client->send_request($req);

