#!/usr/bin/perl

use RPC::XML;
use RPC::XML::Client;

my $host=$ARGV[0];
my $port=$ARGV[1];
my $client = new RPC::XML::Client 'http://' . $host . ':' . $port . '/xmlrpc';

# time in secs between messages
my $sleep_secs=0.25;

while (1) {

    $cnt++;
    if ($cnt % 100 == 0) {   
        $msg='A test message - error ' . $cnt;
    } 
    elsif ($cnt % 40 == 0) {   
        $msg='A test message - warning ' . $cnt;
    } 
    else {
        $msg='A test message ' . $cnt;
    } 
    my $req = RPC::XML::request->new('ME_API.API_StreamsSampler.myteststream.addMessage',$msg);
    my $res = $client->send_request($req);
    
    if ($res->value ne "OK") {
        print "Response type - " .$res->type ."\n";
        print "Response string - " .$res->as_string ."\n";
    }
    else {
        print "Response value - " .$res->value ."\n";
    }
    select(undef,undef,undef,$sleep_secs);
}
