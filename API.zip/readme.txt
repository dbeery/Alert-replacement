------------------
API Test Utilities
M Baker, 2004
------------------

Programs should be run from a DOS/Command prompt.
Running the batch files on their own will give you usage.

Execute and CreateView work with any probe/sampler.

QueueSamplerClient was written specifically for generating a view
for the manual and must be run with a managed entity called
myManEnt and sampler called mySampler.

Examples:

CreateView itrsultra4 4001 myManEnt.mySampler a b
(creates a view)

Execute itrsultra4 4001 myManEnt.mySampler.b-a.updateHeadline headline0 blah
(updates a headline)

Execute itrsultra4 4001 myManEnt.mySampler.b-a.updateHeadline headline4 blah4
(generates an error)

