import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Vector;

import org.apache.xmlrpc.XmlRpcClient;
import org.apache.xmlrpc.XmlRpcException;

/**
 * Simple wrapper for Geneos XML RPC comms
 * @author emiller
 *
 */
public class GeneosXmlRpcClient extends XmlRpcClient
{
	private boolean bDebug = false;
	
	/**
	 * 
	 * @param strHostName
	 * @param nPort
	 * @throws MalformedURLException
	 */
	public GeneosXmlRpcClient(String strHostName, int nPort) throws MalformedURLException 
	{
		super( createXmlRpcURL(strHostName, nPort) );
	}
	
	private static String createXmlRpcURL(String strHostName, int nPort)
	{
		StringBuffer strBuffer = new StringBuffer();
		
		strBuffer.append("http://");
		strBuffer.append(strHostName);
		strBuffer.append(":");
		strBuffer.append(nPort);
		strBuffer.append("/xmlrpc");
		
		return strBuffer.toString();
	}
	
	/**
	 * 
	 * @param bDebug
	 */
	public void setDebug( boolean bDebug )
	{
		this.bDebug = bDebug;
	}
	
	/**
	 * 
	 * @param strMethod
	 * @return The result of the call
	 * @throws XmlRpcException
	 * @throws IOException
	 */
	protected Object callMethod(String strMethod) throws XmlRpcException, IOException
	{		
		if( bDebug ) System.err.println(strMethod);
			
		return execute(strMethod, getArgsVector());
	}
	
	/**
	 * 
	 * @param strMethod
	 * @param arg1
	 * @return The result of the call
	 * @throws XmlRpcException
	 * @throws IOException
	 */
	protected Object callMethod(String strMethod, Object arg1) throws XmlRpcException, IOException
	{		
		if( bDebug ) System.err.println(strMethod + "(" + arg1 + ")");
		
		Vector args = getArgsVector();
		args.add( arg1 );
		return execute(strMethod, args);
	}
	
	/**
	 * 
	 * @param strMethod
	 * @param arg1
	 * @param arg2
	 * @return The result of the call
	 * @throws XmlRpcException
	 * @throws IOException
	 */
	protected Object callMethod(String strMethod, Object arg1, Object arg2) throws XmlRpcException, IOException
	{		
		if( bDebug ) System.err.println(strMethod + "(" + arg1 + "," + arg2 + ")");
		
		Vector args = getArgsVector();
		args.add( arg1 );
		args.add( arg2 );
		return execute(strMethod, args);
	}
	
	private Vector getArgsVector()
	{
		return new Vector();
	}
	
	/**
	 * 
	 * @param strEntity
	 * @param strSampler
	 * @param strGroup
	 * @param strView
	 * @return A View or null if it does not exist
	 * @throws XmlRpcException
	 * @throws IOException
	 */
	public View getView(String strEntity, String strSampler, String strGroup, String strView) throws XmlRpcException, IOException
	{
		View view = new View();
		
		view.strEntity = strEntity;
		view.strSampler = strSampler;
		view.strGroup = strGroup;
		view.strView = strView;
		
		if( !((Boolean)callMethod(view.getSamplerMethodString("viewExists"), strGroup + "-" + strView)).booleanValue() )
			return null;
		
		return view;
	}
	
	/**
	 * 
	 * @param strEntity
	 * @param strSampler
	 * @param strGroup
	 * @param strView
	 * @return A new view or null
	 * @throws XmlRpcException
	 * @throws IOException
	 */
	public View createView(String strEntity, String strSampler, String strGroup, String strView) throws XmlRpcException, IOException
	{
		View view = new View();
		
		view.strEntity = strEntity;
		view.strSampler = strSampler;
		view.strGroup = strGroup;
		view.strView = strView;
		
		if( callMethod(view.getSamplerMethodString("createView"), strView, strGroup).toString().equals("OK") )
			return view;
		
		return null;
	}
	
	/**
	 * 
	 * @author emiller
	 *
	 */
	public class View
	{
		private String strEntity;
		private String strSampler;
		private String strGroup;
		private String strView;
		
		private String getSamplerMethodString(String strMethod)
		{
			StringBuffer strBuffer = new StringBuffer();
			
			strBuffer.append(strEntity);
			strBuffer.append(".");
			strBuffer.append(strSampler);
			strBuffer.append(".");
			strBuffer.append(strMethod);		
			
			return strBuffer.toString();
		}
		
		private String getViewMethodString(String strMethod)
		{
			StringBuffer strBuffer = new StringBuffer();
			
			strBuffer.append(strEntity);
			strBuffer.append(".");
			strBuffer.append(strSampler);
			strBuffer.append(".");
			strBuffer.append(strGroup);
			strBuffer.append("-");
			strBuffer.append(strView);		
			strBuffer.append(".");
			strBuffer.append(strMethod);		
			
			return strBuffer.toString();
		}
		
		/**
		 * 
		 * @param strHeadline
		 * @return true on success
		 * @throws XmlRpcException
		 * @throws IOException
		 */
		public boolean addHeadline(String strHeadline) throws XmlRpcException, IOException
		{
			return callMethod(getViewMethodString("addHeadline"), strHeadline).toString().equals("OK");
		}
		
		/**
		 * 
		 * @param table
		 * @return true on success
		 * @throws XmlRpcException
		 * @throws IOException
		 */
		public boolean updateEntireTable(String[][] table) throws XmlRpcException, IOException
		{
			Vector vecTable = new Vector();
			for (int ix = 0; ix < table.length; ix++)
				vecTable.addElement(new Vector(Arrays.asList(table[ix])));
			
			return callMethod(getViewMethodString("updateEntireTable"), vecTable).toString().equals("OK");
		}
		
		/**
		 * 
		 * @param strCell
		 * @param strValue
		 * @return true on success
		 * @throws XmlRpcException
		 * @throws IOException
		 */
		public boolean updateTableCell(String strCell, String strValue) throws XmlRpcException, IOException
		{
			return callMethod(getViewMethodString("updateTableCell"), strCell, strValue).toString().equals("OK");
		}
	
		/**
		 * 
		 * @param strRowName
		 * @return true on success
		 * @throws XmlRpcException
		 * @throws IOException
		 */
		public boolean addTableRow(String strRowName) throws XmlRpcException, IOException
		{
			return callMethod(getViewMethodString("addTableRow"), strRowName).toString().equals("OK");
		}
		
		/**
		 * 
		 * @param strRowName
		 * @return true on success
		 * @throws XmlRpcException
		 * @throws IOException
		 */
		public boolean removeTableRow(String strRowName) throws XmlRpcException, IOException
		{
			return callMethod(getViewMethodString("removeTableRow"), strRowName).toString().equals("OK");
		}
	}
}
